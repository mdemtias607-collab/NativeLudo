package com.example.nativeludo

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

private val Red = Color(0xFFE84D5B)
private val Green = Color(0xFF20A66A)
private val Yellow = Color(0xFFFFC928)
private val Blue = Color(0xFF3985E8)
private val Palette = listOf(Red, Green, Yellow, Blue)
private val Names = listOf("Red", "Green", "Yellow", "Blue")
private val SafeSquares = setOf(0, 8, 13, 21, 26, 34, 39, 47)
private const val FINISH = 57

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LudoApp() }
    }
}

@Composable
private fun LudoApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("ludo_local", Context.MODE_PRIVATE) }
    var screen by remember { mutableStateOf("home") }
    var mode by remember { mutableStateOf("computer") }
    var playerCount by remember { mutableIntStateOf(2) }
    var playerName by remember { mutableStateOf(prefs.getString("name", "Player") ?: "Player") }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var sound by remember { mutableStateOf(prefs.getBoolean("sound", true)) }
    var vibration by remember { mutableStateOf(prefs.getBoolean("vibration", true)) }
    var language by remember { mutableStateOf(prefs.getString("language", "English") ?: "English") }
    var game by remember { mutableStateOf(GameState.new(2)) }
    var toast by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Color(0xFF8DB8FF)) else lightColorScheme(primary = Color(0xFF3867D6))) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when (screen) {
                "home" -> HomeScreen(
                    name = playerName,
                    onPlay = { screen = "setup" },
                    onProfile = { screen = "profile" },
                    onSettings = { screen = "settings" },
                    onStats = { screen = "stats"; },
                    onResume = {
                        val loaded = loadGame(prefs)
                        if (loaded != null) { game = loaded; screen = "game" } else toast = "No saved match found"
                    },
                    hasSave = prefs.contains("game"),
                    message = toast
                )
                "setup" -> SetupScreen(mode, { mode = it }, playerCount, { playerCount = it }, {
                    game = GameState.new(playerCount, mode == "computer")
                    saveGame(prefs, game)
                    screen = "game"
                }, { screen = "home" })
                "game" -> GameScreen(
                    state = game,
                    onState = { game = it; saveGame(prefs, it) },
                    onBack = { screen = "home" },
                    onRestart = { game = GameState.new(playerCount, mode == "computer"); saveGame(prefs, game) },
                    sound = sound,
                    message = language
                )
                "settings" -> SettingsScreen(dark, { dark = it; prefs.edit().putBoolean("dark", it).apply() },
                    sound, { sound = it; prefs.edit().putBoolean("sound", it).apply() },
                    vibration, { vibration = it; prefs.edit().putBoolean("vibration", it).apply() },
                    language, { language = it; prefs.edit().putString("language", it).apply() }, { screen = "home" })
                "profile" -> ProfileScreen(playerName, { playerName = it; prefs.edit().putString("name", it).apply() }, { screen = "home" })
                "stats" -> StatsScreen(prefs, { screen = "home" })
            }
        }
    }
}

@Composable
private fun HomeScreen(name: String, onPlay: () -> Unit, onProfile: () -> Unit, onSettings: () -> Unit,
                       onStats: () -> Unit, onResume: () -> Unit, hasSave: Boolean, message: String) {
    Column(Modifier.fillMaxSize().background(Color(0xFFF4F6FB)).verticalScroll(rememberScrollState()).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(30.dp))
        Text("LUDO", fontSize = 42.sp, fontWeight = FontWeight.Black, color = Color(0xFF273A75))
        Text("PLAY • ROLL • WIN", fontSize = 13.sp, letterSpacing = 3.sp, color = Color.Gray)
        Spacer(Modifier.height(22.dp))
        LudoBoardPreview(Modifier.fillMaxWidth().height(260.dp))
        Spacer(Modifier.height(26.dp))
        Text("Welcome, $name!", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Ready for your next match?", color = Color.Gray)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onPlay, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
            Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("NEW GAME", fontWeight = FontWeight.Bold)
        }
        if (hasSave) OutlinedButton(onClick = onResume, modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(50.dp)) {
            Icon(Icons.Default.Replay, null); Spacer(Modifier.width(8.dp)); Text("RESUME GAME")
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HomeTile("Profile", Icons.Default.Person, onProfile, Modifier.weight(1f))
            HomeTile("Statistics", Icons.Default.BarChart, onStats, Modifier.weight(1f))
            HomeTile("Settings", Icons.Default.Settings, onSettings, Modifier.weight(1f))
        }
        if (message.isNotBlank()) Text(message, color = Color(0xFFB3261E), modifier = Modifier.padding(8.dp))
        Spacer(Modifier.height(18.dp))
        Text("Offline • No account required", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
private fun HomeTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier) {
    Card(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Color(0xFF3867D6))
            Spacer(Modifier.height(5.dp))
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun LudoBoardPreview(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val cell = size.minDimension / 15f
        val boardW = cell * 15
        val left = (size.width - boardW) / 2
        val top = (size.height - boardW) / 2
        drawRect(Color.White, Offset(left, top), Size(boardW, boardW))
        val zones = listOf(
            Triple(0, 0, Red), Triple(9, 0, Green),
            Triple(0, 9, Blue), Triple(9, 9, Yellow)
        )
        zones.forEach { (x, y, c) ->
            drawRect(c, Offset(left + x * cell, top + y * cell), Size(6 * cell, 6 * cell))
            drawRect(Color.White, Offset(left + (x + 1) * cell, top + (y + 1) * cell), Size(4 * cell, 4 * cell))
            for (r in 0..1) for (col in 0..1) drawCircle(c, cell * .32f,
                Offset(left + (x + 2 + col * 2) * cell, top + (y + 2 + r * 2) * cell))
        }
        for (i in 0..15) {
            drawLine(Color.LightGray, Offset(left + i * cell, top), Offset(left + i * cell, top + boardW), 1f)
            drawLine(Color.LightGray, Offset(left, top + i * cell), Offset(left + boardW, top + i * cell), 1f)
        }
        val center = Offset(left + 7.5f * cell, top + 7.5f * cell)
        drawCircle(Color(0xFF273A75), cell * 1.35f, center)
        drawCircle(Color.White, cell * .8f, center)
    }
}

@Composable
private fun SetupScreen(mode: String, onMode: (String) -> Unit, count: Int, onCount: (Int) -> Unit,
                        onStart: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
        Text("New Match", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Choose how you want to play", color = Color.Gray)
        Spacer(Modifier.height(24.dp))
        Text("GAME MODE", fontWeight = FontWeight.Bold)
        listOf("computer" to "Play vs Computer", "local" to "Pass & Play (Local Players)").forEach { (key, title) ->
            Card(Modifier.fillMaxWidth().padding(top = 10.dp).clickable { onMode(key) },
                colors = CardDefaults.cardColors(containerColor = if (mode == key) Color(0xFFE5ECFF) else MaterialTheme.colorScheme.surface)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(mode == key, onClick = { onMode(key) })
                    Spacer(Modifier.width(8.dp)); Text(title, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("NUMBER OF PLAYERS", fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (2..4).forEach { n ->
                FilterChip(selected = count == n, onClick = { onCount(n) }, label = { Text("$n Players") })
            }
        }
        Spacer(Modifier.height(28.dp))
        Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text("START GAME") }
        TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
}

@Composable
private fun GameScreen(state: GameState, onState: (GameState) -> Unit, onBack: () -> Unit,
                       onRestart: () -> Unit, sound: Boolean, message: String) {
    var showRules by remember { mutableStateOf(false) }
    var showQuit by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("Roll the dice to begin.") }

    LaunchedEffect(state.currentPlayer, state.dice, state.finished) {
        if (state.aiEnabled && state.currentPlayer == 1 && !state.finished) {
            delay(700)
            val rolled = if (state.dice == 0) state.copy(dice = Random.nextInt(1, 7)) else state
            val moves = rolled.legalMoves()
            if (moves.isNotEmpty()) {
                val choice = moves.maxByOrNull { idx ->
                    val p = rolled.positions[1][idx]
                    (if (p + rolled.dice >= FINISH) 100 else 0) + (if (p < 0 && rolled.dice == 6) 20 else 0) + p
                } ?: moves.first()
                onState(rolled.move(choice))
                notice = "Computer played."
            } else {
                onState(rolled.nextTurn())
                notice = "Computer has no valid move."
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = { showQuit = true }) { Icon(Icons.Default.ArrowBack, "Back") }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("LUDO MATCH", fontWeight = FontWeight.Black, fontSize = 18.sp)
                Text(if (state.finished) "Match complete" else "${Names[state.currentPlayer]}'s turn", color = Palette[state.currentPlayer])
            }
            IconButton(onClick = { showRules = true }) { Icon(Icons.Default.HelpOutline, "Rules") }
        }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(10.dp)) {
                LudoBoard(state, Modifier.fillMaxWidth().aspectRatio(1f)) { token ->
                    if (!state.aiEnabled || state.currentPlayer != 1) {
                        if (state.dice != 0 && token in state.legalMoves() && !state.finished) {
                            onState(state.move(token))
                            notice = "Token moved."
                        } else notice = if (state.dice == 0) "Roll the dice first." else "Choose a highlighted token."
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Palette[state.currentPlayer].copy(alpha = .13f))) {
                Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("CURRENT PLAYER", fontSize = 10.sp, color = Color.Gray)
                    Text(Names[state.currentPlayer], fontWeight = FontWeight.Bold, color = Palette[state.currentPlayer])
                    Text(if (state.dice == 0) "🎲 —" else "🎲 ${state.dice}", fontSize = 24.sp, fontWeight = FontWeight.Black)
                }
            }
            Button(onClick = {
                if (!state.finished && (!state.aiEnabled || state.currentPlayer != 1) && state.dice == 0) {
                    val roll = Random.nextInt(1, 7)
                    val next = state.copy(dice = roll)
                    onState(next)
                    notice = "You rolled $roll."
                    if (next.legalMoves().isEmpty()) {
                        onState(next.nextTurn())
                        notice = "No valid move. Turn passed."
                    } else if (next.legalMoves().size == 1) {
                        // Keep selection explicit, so the user sees the legal move.
                        notice = "Select the highlighted token."
                    }
                }
            }, modifier = Modifier.weight(1f).height(64.dp), enabled = !state.finished && state.dice == 0 && (!state.aiEnabled || state.currentPlayer != 1)) {
                Icon(Icons.Default.Casino, null); Spacer(Modifier.width(6.dp)); Text("ROLL DICE")
            }
        }
        Text(notice, modifier = Modifier.padding(vertical = 8.dp), color = Color.Gray)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { onState(state.copy(dice = 0)) }, modifier = Modifier.weight(1f), enabled = state.dice != 0) { Text("Cancel Roll") }
            OutlinedButton(onClick = onRestart, modifier = Modifier.weight(1f)) { Text("Restart") }
        }
        if (state.finished) {
            Card(Modifier.fillMaxWidth().padding(top = 8.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF0C2))) {
                Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🏆 ${Names[state.winner]} WINS!", fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Text("Congratulations!")
                    Button(onClick = onRestart) { Text("PLAY AGAIN") }
                }
            }
        }
        if (showRules) AlertDialog(onDismissRequest = { showRules = false }, title = { Text("Ludo Rules") },
            text = { Text("• Roll a 6 to bring a token onto the board.\n• Select a highlighted token after rolling.\n• Landing on an opponent outside a safe square sends it home.\n• Reach the finish exactly to complete a token.\n• First player to finish all four tokens wins.") },
            confirmButton = { TextButton(onClick = { showRules = false }) { Text("Got it") } })
        if (showQuit) AlertDialog(onDismissRequest = { showQuit = false }, title = { Text("Leave match?") },
            text = { Text("Your current game is saved locally. Return to the home screen?") },
            confirmButton = { TextButton(onClick = { showQuit = false; onBack() }) { Text("Home") } },
            dismissButton = { TextButton(onClick = { showQuit = false }) { Text("Keep Playing") } })
    }
}

@Composable
private fun LudoBoard(state: GameState, modifier: Modifier = Modifier, onToken: (Int) -> Unit) {
    Canvas(modifier) {
        val cell = size.minDimension / 15f
        val board = cell * 15
        val left = (size.width - board) / 2
        val top = (size.height - board) / 2
        drawRect(Color(0xFFFDFDFD), Offset(left, top), Size(board, board))
        // Four home bases
        val zones = listOf(Triple(0, 0, Red), Triple(9, 0, Green), Triple(0, 9, Blue), Triple(9, 9, Yellow))
        zones.forEach { (x, y, c) ->
            drawRect(c, Offset(left + x * cell, top + y * cell), Size(6 * cell, 6 * cell))
            drawRect(Color.White, Offset(left + (x + 1) * cell, top + (y + 1) * cell), Size(4 * cell, 4 * cell))
            for (r in 0..1) for (col in 0..1) {
                drawCircle(c, cell * .34f, Offset(left + (x + 2 + col * 2) * cell, top + (y + 2 + r * 2) * cell))
            }
        }
        val route = routeCells()
        route.forEachIndexed { i, p ->
            val c = when {
                i == 0 -> Red
                i == 13 -> Green
                i == 26 -> Yellow
                i == 39 -> Blue
                i in SafeSquares -> Color(0xFFDDE6F5)
                else -> Color.White
            }
            drawRect(c, Offset(left + p.first * cell, top + p.second * cell), Size(cell, cell))
            drawRect(Color(0xFFCFD5DF), Offset(left + p.first * cell, top + p.second * cell), Size(cell, cell), style = Stroke(1f))
        }
        // Colored home lanes leading to center
        val lanes = listOf(
            Pair(Red, (1..5).map { 7 to it }),
            Pair(Green, (1..5).map { it to 7 }),
            Pair(Yellow, (9..13).map { 7 to it }),
            Pair(Blue, (9..13).map { it to 7 })
        )
        lanes.forEach { (c, points) -> points.forEach { p ->
            drawRect(c.copy(alpha = .72f), Offset(left + p.first * cell, top + p.second * cell), Size(cell, cell))
            drawRect(Color.White.copy(alpha = .4f), Offset(left + p.first * cell, top + p.second * cell), Size(cell, cell), style = Stroke(1f))
        } }
        // Center triangles
        val cx = left + 7.5f * cell
        val cy = top + 7.5f * cell
        drawCircle(Color(0xFF263A75), cell * 1.15f, Offset(cx, cy))
        drawCircle(Color.White, cell * .62f, Offset(cx, cy))
        // tokens
        state.positions.forEachIndexed { player, tokens ->
            tokens.forEachIndexed { token, pos ->
                val point = if (pos < 0) homeTokenCell(player, token) else if (pos >= FINISH) finishTokenCell(player, token) else routeCells()[(pos + player * 13) % 52]
                val px = left + (point.first + .5f) * cell
                val py = top + (point.second + .5f) * cell
                val isLegal = player == state.currentPlayer && token in state.legalMoves()
                drawCircle(Color.Black.copy(alpha = .18f), cell * .38f, Offset(px + 1.5f, py + 2f))
                drawCircle(Palette[player], cell * .34f, Offset(px, py))
                drawCircle(Color.White, cell * .20f, Offset(px, py), style = Stroke(if (isLegal) 3f else 1.5f))
                if (isLegal) drawCircle(Color(0xFF111111), cell * .40f, Offset(px, py), style = Stroke(2.5f))
                drawCircle(Color.White.copy(alpha = .85f), cell * .07f, Offset(px - cell * .07f, py - cell * .08f))
            }
        }
    }
}

private fun routeCells(): List<Pair<Int, Int>> = listOf(
    1 to 6,1 to 5,1 to 4,1 to 3,1 to 2,2 to 1,3 to 1,4 to 1,5 to 1,6 to 1,
    6 to 0,7 to 0,8 to 0,8 to 1,8 to 2,8 to 3,8 to 4,8 to 5,9 to 6,10 to 6,
    11 to 6,12 to 6,13 to 6,14 to 7,13 to 8,12 to 8,11 to 8,10 to 8,9 to 8,
    8 to 9,8 to 10,8 to 11,8 to 12,8 to 13,7 to 14,6 to 13,6 to 12,6 to 11,
    6 to 10,6 to 9,5 to 8,4 to 8,3 to 8,2 to 8,1 to 8,0 to 7,1 to 6,2 to 6,
    3 to 6,4 to 6,5 to 6
)

private fun homeTokenCell(player: Int, token: Int): Pair<Int, Int> {
    val offsets = listOf(Triple(2, 2, Red), Triple(11, 2, Green), Triple(11, 11, Yellow), Triple(2, 11, Blue))
    val (x, y, _) = offsets[player]
    return (x + (token % 2) * 2) to (y + (token / 2) * 2)
}
private fun finishTokenCell(player: Int, token: Int): Pair<Int, Int> {
    val x = when (player) { 0 -> 6; 1 -> 8; 2 -> 8; else -> 6 }
    val y = when (player) { 0 -> 8; 1 -> 6; 2 -> 8; else -> 6 }
    return (x + token % 2) to (y + token / 2)
}

private data class GameState(
    val positions: List<List<Int>>,
    val currentPlayer: Int,
    val dice: Int = 0,
    val finished: Boolean = false,
    val winner: Int = -1,
    val aiEnabled: Boolean = false,
    val playerCount: Int = 2,
    val wins: Int = 0
) {
    fun legalMoves(): List<Int> {
        if (dice !in 1..6 || finished) return emptyList()
        return positions[currentPlayer].indices.filter { i ->
            val p = positions[currentPlayer][i]
            if (p < 0) dice == 6 else p + dice <= FINISH
        }
    }

    fun move(token: Int): GameState {
        if (token !in legalMoves()) return this
        val updated = positions.map { it.toMutableList() }.toMutableList()
        val old = updated[currentPlayer][token]
        val nextPos = if (old < 0) 0 else old + dice
        updated[currentPlayer][token] = nextPos
        if (nextPos in 0 until 52) {
            val global = (nextPos + currentPlayer * 13) % 52
            if (global !in SafeSquares) {
                for (p in 0 until playerCount) if (p != currentPlayer) {
                    for (t in 0..3) {
                        val other = updated[p][t]
                        if (other >= 0 && other < 52 && (other + p * 13) % 52 == global) updated[p][t] = -1
                    }
                }
            }
        }
        val won = updated[currentPlayer].all { it >= FINISH }
        val retainTurn = dice == 6 || nextPos == FINISH
        return copy(
            positions = updated.map { it.toList() },
            currentPlayer = if (retainTurn || won) currentPlayer else (currentPlayer + 1) % playerCount,
            dice = 0, finished = won, winner = if (won) currentPlayer else -1,
            wins = if (won && currentPlayer == 0) wins + 1 else wins
        )
    }

    fun nextTurn(): GameState = copy(currentPlayer = (currentPlayer + 1) % playerCount, dice = 0)
    companion object {
        fun new(count: Int, ai: Boolean = false): GameState = GameState(
            positions = List(4) { p -> List(4) { -1 } },
            currentPlayer = 0, playerCount = count, aiEnabled = ai
        )
    }
}

private fun saveGame(context: Context, state: GameState) {
    val positions = state.positions.joinToString(";") { it.joinToString(",") }
    context.getSharedPreferences("ludo_local", Context.MODE_PRIVATE).edit()
        .putString("game", positions)
        .putInt("current", state.currentPlayer).putInt("dice", state.dice)
        .putBoolean("finished", state.finished).putInt("winner", state.winner)
        .putBoolean("ai", state.aiEnabled).putInt("count", state.playerCount).putInt("wins", state.wins).apply()
}
private fun loadGame(context: Context): GameState? {
    val p = context.getSharedPreferences("ludo_local", Context.MODE_PRIVATE)
    val raw = p.getString("game", null) ?: return null
    return try {
        val positions = raw.split(";").map { row -> row.split(",").map { it.toInt() } }
        if (positions.size != 4 || positions.any { it.size != 4 }) return null
        GameState(positions, p.getInt("current", 0), p.getInt("dice", 0), p.getBoolean("finished", false),
            p.getInt("winner", -1), p.getBoolean("ai", false), p.getInt("count", 2), p.getInt("wins", 0))
    } catch (_: Exception) { null }
}

@Composable
private fun SettingsScreen(dark: Boolean, onDark: (Boolean) -> Unit, sound: Boolean, onSound: (Boolean) -> Unit,
                           vibration: Boolean, onVibration: (Boolean) -> Unit, language: String,
                           onLanguage: (String) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Text("Settings", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        SettingSwitch("Dark Mode", dark, onDark)
        SettingSwitch("Sound Effects", sound, onSound)
        SettingSwitch("Vibration", vibration, onVibration)
        Text("Language", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 20.dp, bottom = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(language == "English", { onLanguage("English") }, label = { Text("English") })
            FilterChip(language == "বাংলা", { onLanguage("বাংলা") }, label = { Text("বাংলা") })
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Done") }
    }
}
@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 16.sp)
        Switch(checked, onChange)
    }
}

@Composable
private fun ProfileScreen(name: String, onName: (String) -> Unit, onBack: () -> Unit) {
    var draft by remember(name) { mutableStateOf(name) }
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Text("Player Profile", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Box(Modifier.size(90.dp).background(Color(0xFFE5ECFF), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, null, modifier = Modifier.size(54.dp), tint = Color(0xFF3867D6))
        }
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(draft, { draft = it.take(20) }, label = { Text("Player name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(onClick = { onName(draft.ifBlank { "Player" }); onBack() }, modifier = Modifier.fillMaxWidth()) { Text("Save Profile") }
        TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
    }
}

@Composable
private fun StatsScreen(prefs: android.content.SharedPreferences, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Text("Statistics", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        StatCard("Matches saved", if (prefs.contains("game")) "1" else "0")
        StatCard("Player wins", prefs.getInt("wins", 0).toString())
        StatCard("Game mode", "Offline")
        Spacer(Modifier.weight(1f))
        Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
}
@Composable
private fun StatCard(label: String, value: String) {
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, modifier = Modifier.weight(1f), color = Color.Gray)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        }
    }
}
