# Native Ludo — Termux Android Project

এটি Kotlin + Jetpack Compose দিয়ে তৈরি একটি native Android Ludo source project। WebView, Firebase বা Admin Panel নেই।

## অন্তর্ভুক্ত
- Native Android UI
- Offline Pass & Play এবং basic Computer opponent
- ২–৪ player নির্বাচন
- Dice, token selection, capture, safe cells, finish/win logic
- Profile name, settings, local save/resume, rules screen
- Gradle build configuration

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এই ZIP একটি starter implementation, সব ৫২টি প্রস্তাবিত feature production-ready নয়। Online multiplayer, real achievement/reward economy, পূর্ণ match-history database, polished sound/vibration integration, complete localization, and comprehensive Ludo rule validation এখনো সম্পূর্ণ বাস্তবায়িত হয়নি। প্রথমে build/test করুন এবং বাস্তব ডিভাইসে গেমের সব চাল পরীক্ষা করুন।

## Build করার আগে
Android SDK ও Gradle environment লাগবে। Termux-এর সব সংস্করণে Android SDK/Gradle build সহজে কাজ নাও করতে পারে; সবচেয়ে নির্ভরযোগ্য বিকল্প হলো Termux-এর মধ্যে compatible Linux environment/SDK setup, অথবা Android Studio-তে একই project build করা।

### সাধারণ Termux preparation
```bash
pkg update
pkg upgrade
pkg install openjdk-17 gradle unzip
java -version
gradle --version
```

Android SDK-এর platform 35 এবং Build Tools 35.x ইনস্টল করে `ANDROID_HOME` সেট করুন। উদাহরণ:
```bash
export ANDROID_HOME="$HOME/android-sdk"
export PATH="$PATH:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin"
```
SDK-এর অবস্থান আপনার ইনস্টলেশনের সঙ্গে মিলিয়ে নেবেন।

## Build
Project root-এ:
```bash
gradle assembleDebug
```
যদি আপনার environment Gradle wrapper তৈরি করতে পারে, পরে `./gradlew assembleDebug` ব্যবহার করা যাবে। APK সাধারণত এখানে তৈরি হবে:
`app/build/outputs/apk/debug/app-debug.apk`

## Install
USB debugging/ADB বা Android-এর file manager দিয়ে APK install করুন। Unknown app install permission প্রয়োজন হতে পারে।

## Rules note
এই starter-এ board drawing ও token movement demonstrative implementation। release-এর আগে standard Ludo path geometry, team mode, exact home-lane progression, capture and extra-turn rules, AI behavior, state restoration, accessibility, and tests যাচাই ও উন্নত করুন।
